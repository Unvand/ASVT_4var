; ============================================
; ??????? 4: ???????? (T), ????? 3, 2.4 ????/?
; ============================================
        ORG     0000H
        LJMP    START

        ORG     0100H
START:
        ; ????????? ??????? ??? 2400 ???/?
        MOV     TMOD, #20H     
        MOV     TH1, #0F4H     ; ????????? ??? 2.4? ??? 11.059 ??? 
        SETB    TR1            

        ; ????????? ?????
        MOV     PCON, #00H     ; SMOD = 0 
        MOV     SCON, #0C0H    ; ????? 3: SM0=1, SM1=1 [cite: 28]

        ; ??????
        MOV     50H, #'M'
        MOV     51H, #'A'
        MOV     52H, #'H'
        MOV     53H, #'A'
        MOV     54H, #'4'
        MOV     55H, #'-'
        MOV     56H, #'O'
        MOV     57H, #'K'

        MOV     R0, #50H       
        MOV     R7, #8         

SEND_LOOP:
        MOV     A, @R0         
        SETB    TB8            ; ??????????? ??? ?????? 3 ? Proteus 
        MOV     SBUF, A        
WAIT_TI:
        JNB     TI, WAIT_TI    
        CLR     TI             
        INC     R0             
        DJNZ    R7, SEND_LOOP  

        SJMP    $              
                 ; ?????????

; ??????????? ??????? (SFR)
TMOD    EQU     89H
TH1     EQU     8DH
TL1     EQU     8BH
TR1     BIT     8EH
PCON    EQU     87H
SCON    EQU     98H
SBUF    EQU     99H
TI      BIT     98H.1          ; ???? TI (SCON.1) [cite: 18]
TB8     BIT     98H.3          ; ??? TB8 (SCON.3) [cite: 21]

        END